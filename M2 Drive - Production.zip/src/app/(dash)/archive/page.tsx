import { ReactNode } from 'react';

export default function page() {
    return (
        <div>
            page Component
        </div>
    );
}