'use client'

import FileContentViewer from '@/viewer/FileContentViewer';


export default function FileViewPage() {

    return (<FileContentViewer />);
}